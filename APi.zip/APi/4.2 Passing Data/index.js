import express from "express";
import {dirname} from "path";

// 

const app = express();
const port = 3000;

// 
app.get("/", (req, res) => {
    res.render("index.ejs");
});

app.post("/submit", (req, res) => {
    res.render("index.ejs",
        {name : req.body["fName"]}
    );
});

app.listen(port,() => {
    console.log(`Sever running on Port ${port}.`);
});